# mlr3learners.randomforest 0.1.2

- More fixes for `importance()` method.


# mlr3learners.randomforest 0.1.1.9000

- Same as previous version.


# mlr3learners.randomforest 0.1.1

- Fix `importance()` calculation.


# mlr3learners.randomforest 0.1.0.9000

- Internal changes only.


# mlr3learners.randomforest 0.1.0

* Initial release
