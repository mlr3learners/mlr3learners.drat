library(testthat)
library(mlr3learners.nnet)

test_check("mlr3learners.nnet")
