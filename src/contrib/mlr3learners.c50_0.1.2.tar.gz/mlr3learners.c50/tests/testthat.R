library(testthat)
library(mlr3learners.c50)

test_check("mlr3learners.c50")
