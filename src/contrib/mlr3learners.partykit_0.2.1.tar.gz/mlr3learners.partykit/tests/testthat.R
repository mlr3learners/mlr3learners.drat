library(testthat)
library(mlr3learners.partykit)

test_check("mlr3learners.partykit")
