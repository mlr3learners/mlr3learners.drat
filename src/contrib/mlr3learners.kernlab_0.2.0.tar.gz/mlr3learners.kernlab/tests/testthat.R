library(testthat)
library(mlr3learners.kernlab)

test_check("mlr3learners.kernlab")
