library(testthat)
library(mlr3learners.gss)

test_check("mlr3learners.gss")
