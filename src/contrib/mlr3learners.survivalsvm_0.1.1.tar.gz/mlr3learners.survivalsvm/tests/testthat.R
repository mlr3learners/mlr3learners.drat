library(testthat)
library(mlr3learners.survivalsvm)

test_check("mlr3learners.survivalsvm")
