library(testthat)
library(mlr3learners.logspline)

test_check("mlr3learners.logspline")
