library(testthat)
library(mlr3learner.ksvm)

test_check("mlr3learner.ksvm")
