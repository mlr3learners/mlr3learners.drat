library(testthat)
library(mlr3learners.survival)

test_check("mlr3learners.survival")
