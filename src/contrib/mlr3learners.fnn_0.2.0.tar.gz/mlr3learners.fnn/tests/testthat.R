library(testthat)
library(mlr3learners.fnn)

test_check("mlr3learners.fnn")
