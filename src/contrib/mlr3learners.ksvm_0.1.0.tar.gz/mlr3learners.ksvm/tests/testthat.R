library(testthat)
library(mlr3learners.ksvm)

test_check("mlr3learners.ksvm")
