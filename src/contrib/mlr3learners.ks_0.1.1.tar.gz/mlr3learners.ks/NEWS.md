# mlr3learners.ks 0.1.1

- Removed remotes dependencies
- Minor internal bug fix

# mlr3learners.ks 0.1.0

- Initial release.


