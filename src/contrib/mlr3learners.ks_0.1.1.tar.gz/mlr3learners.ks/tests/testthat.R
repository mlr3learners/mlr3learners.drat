library(testthat)
library(mlr3learners.ks)

test_check("mlr3learners.ks")
