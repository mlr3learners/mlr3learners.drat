library(testthat)
library(mlr3learners.mboost)

test_check("mlr3learners.mboost")
