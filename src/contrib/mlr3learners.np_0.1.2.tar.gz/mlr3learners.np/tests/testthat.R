library(testthat)
library(mlr3learners.np)

test_check("mlr3learners.np")
