library(testthat)
library(mlr3learners.gbm)

test_check("mlr3learners.gbm")
