library(testthat)
library(mlr3learners.liblinear)

test_check("mlr3learners.liblinear")
