# mlr3learners.locfit 0.1.0

- Initial release.


