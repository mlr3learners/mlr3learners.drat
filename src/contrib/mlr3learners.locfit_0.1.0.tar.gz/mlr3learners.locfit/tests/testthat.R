library(testthat)
library(mlr3learners.locfit)

test_check("mlr3learners.locfit")
