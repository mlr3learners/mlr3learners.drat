library(testthat)
library(mlr3learners.C50)

test_check("mlr3learners.C50")
