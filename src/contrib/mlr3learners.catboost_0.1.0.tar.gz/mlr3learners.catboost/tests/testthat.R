library(testthat)
library(mlr3learners.catboost)

test_check("mlr3learners.catboost")
