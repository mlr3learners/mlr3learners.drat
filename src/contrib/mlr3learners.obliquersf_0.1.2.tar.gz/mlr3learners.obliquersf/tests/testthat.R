library(testthat)
library(mlr3learners.obliquersf)

test_check("mlr3learners.obliquersf")
