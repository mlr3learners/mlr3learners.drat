setcollapse <- function(x) {
  paste0("{", paste0(x, collapse = ", "), "}")
}
