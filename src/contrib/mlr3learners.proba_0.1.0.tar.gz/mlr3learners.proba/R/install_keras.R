#' @title Install Keras and the TensorFlow backend
#' @description See [keras::install_keras] for more details.
#' @param method,conda,version,tensorflow,extra_packages,... See [keras::install_keras].
#' @export
install_keras = keras::install_keras
