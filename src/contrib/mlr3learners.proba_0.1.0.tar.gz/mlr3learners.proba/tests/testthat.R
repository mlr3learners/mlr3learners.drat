library(testthat)
library(mlr3learners.proba)

test_check("mlr3learners.proba")
