library(testthat)
library(mlr3learners.plugdensity)

test_check("mlr3learners.plugdensity")
