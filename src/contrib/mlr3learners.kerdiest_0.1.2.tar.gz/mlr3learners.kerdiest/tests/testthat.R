library(testthat)
library(mlr3learners.kerdiest)

test_check("mlr3learners.kerdiest")
