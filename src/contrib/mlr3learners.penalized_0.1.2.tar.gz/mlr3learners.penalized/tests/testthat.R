library(testthat)
library(mlr3learners.penalized)

test_check("mlr3learners.penalized")
