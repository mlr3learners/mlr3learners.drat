# mlr3learners.nnet 0.1.0

- Initial release

# mlr3learners.nnet 0.1.0.9000

- Internal changes only.
