library(testthat)
library(mlr3learners.flexsurv)

test_check("mlr3learners.flexsurv")
