library(testthat)
library(mlr3learners.pendensity)

test_check("mlr3learners.pendensity")
