library(testthat)
library(mlr3learners.extratrees)

test_check("mlr3learners.extratrees")
