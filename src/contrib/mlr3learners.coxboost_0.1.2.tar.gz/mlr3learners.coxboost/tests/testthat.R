library(testthat)
library(mlr3learners.coxboost)

test_check("mlr3learners.coxboost")
