library(testthat)
library(mlr3learners.rweka)

test_check("mlr3learners.rweka")
