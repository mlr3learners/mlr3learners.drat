library(testthat)
library(mlr3learners.sm)

test_check("mlr3learners.sm")
