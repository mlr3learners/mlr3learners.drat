library(testthat)
library(mlr3learners.pycox)

test_check("mlr3learners.pycox")
