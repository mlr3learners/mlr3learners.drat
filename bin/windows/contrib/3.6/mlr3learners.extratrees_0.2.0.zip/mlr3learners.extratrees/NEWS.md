# mlr3learners.extratrees 0.2.0

- Add param "quantile" for `LearnerRegrExtraTrees`
- Use `$help()` method from super class
- Optimize .onLoad() and add .Unload()
- Test on all platforms via GitHub Actions


# mlr3learners.extratrees 0.1.0

* Added a `NEWS.md` file to track changes to the package.
