# mlr3learners.liblinear 0.2.0.9000

- Same as previous version.


# mlr3learners.liblinear 0.2.0

- Initial release


# mlr3learners.liblinear 0.1.0.9000

* Added a `NEWS.md` file to track changes to the package.
