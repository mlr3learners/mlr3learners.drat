# mlr3learners.c50 0.1.2

- Forgot to rename `man` slot in the constructor with new package name


# mlr3learners.c50 0.1.1.9000

- Internal changes only.


# mlr3learners.c50 0.1.1

- Rename from mlr3learners.C50 to mlr3learners.c50


# mlr3learners.C50 0.1.0.9000

- Internal changes only.


# mlr3learners.C50 0.1.0

- Initial release


