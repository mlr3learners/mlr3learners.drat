# mlr3learners.kernlab 0.2.0

- Add Paramtest
- Rename package from "mlr3learners.ksvm" to "mlr3learners.kernlab"
- Add lintr

# mlr3learners.kernlab 0.1.1.9000

- Internal changes only

# mlr3learners.kernlab 0.1.1

- Update documentation, methods and DESCRIPTION
- Add man for help method
- gh actions workflow
- Remove travis
- Remove appveyor
- Update zzz.R
- Add to drat

# mlr3learners.kernlab 0.1.0.9000

- Internal changes only.

# mlr3learner.kernlab 0.1.0

- Added a `NEWS.md` file to track changes to the package.
