# mlr3learners.mboost 0.2.0

- Add `LearnerClassifGAMBoost`
- Add `LearnerClassifGLMBoost`
- Use Roxygen R6 notation
- Make train and predict functions private
- Test on GitHub Actions

# mlr3learners.mboost 0.1.0.9000

- Internal changes only.


# mlr3learners.mboost 0.1.0.9000

- Internal changes only.

# mlr3learners.mboost 0.1.0

- Initial release
