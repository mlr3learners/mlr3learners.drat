# mlr3learners.fnn 0.2.0.9000

- Same as previous version.


# mlr3learners.fnn 0.2.0

- Use `$help()` method from super class
- Optimize .onLoad() and add .Unload()
- Test on all platforms via GitHub Actions


# mlr3learners.fnn 0.1.0.9000

- Internal changes only.

# mlr3learners.fnn 0.1.0

- Initial release
