# mlr3learners.obliquersf 0.1.0

- Initial release.


