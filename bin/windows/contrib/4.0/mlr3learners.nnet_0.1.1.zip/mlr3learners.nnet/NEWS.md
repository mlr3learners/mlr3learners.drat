# mlr3learners.nnet 0.1.1.9000

- Bump version to devel

# mlr3learners.nnet 0.1.0

- Initial release

# mlr3learners.nnet 0.1.0.9000

- Internal changes only.
