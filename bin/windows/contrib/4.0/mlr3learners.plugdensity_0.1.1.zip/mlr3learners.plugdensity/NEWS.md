# mlr3learners.plugdensity 0.1.1

- Removed remotes dependencies
- Minor internal bug fix

# mlr3learners.plugdensity 0.1.0

- Initial release.
