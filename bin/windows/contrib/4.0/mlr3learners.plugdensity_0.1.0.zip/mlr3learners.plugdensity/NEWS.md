# mlr3learners.plugdensity 0.1.0

- Initial release.


